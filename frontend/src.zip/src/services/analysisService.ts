import axios from "axios";

import type {
    UploadResponse,
    JobDescriptionAnalysis,
    MatchResponse,
} from "../types/analysis";

const api = axios.create({
    baseURL: "http://127.0.0.1:8000",
});

export async function uploadResume(
    file: File
): Promise<UploadResponse> {

    const formData = new FormData();

    formData.append("file", file);

    const response = await api.post(
        "/resume/upload",
        formData,
        {
            headers: {
                "Content-Type": "multipart/form-data",
            },
        }
    );

    return response.data.data;

}

export async function analyzeJobDescription(
    jobDescription: string
): Promise<JobDescriptionAnalysis> {

    const response =
        await api.post<JobDescriptionAnalysis>(
            "/analysis/job-description",
            {
                job_description: jobDescription,
            }
        );

    return response.data;

}

export async function matchResume(
    resumeFilename: string,
    jobDescription: string
): Promise<MatchResponse> {

    const response =
        await api.post<MatchResponse>(
            "/analysis/match",
            {
                resume_filename: resumeFilename,
                job_description: jobDescription,
            }
        );

    return response.data;

}