export interface UploadResponse {
  filename: string;
  message: string;
}

export interface JobDescriptionRequest {
  job_description: string;
}

export interface JobDescriptionAnalysis {
  skills: string[];
  technologies: string[];
  experience: string[];
  education: string[];
}

export interface MatchRequest {
  resume_filename: string;
  job_description: string;
}

export interface MatchResponse {
  score: number;
  matched_skills: string[];
  missing_skills: string[];
  extra_skills: string[];
}