import styles from "../../app/App.module.css";

import Container from "../../shared/ui/Container/Container";
import Card from "../../shared/ui/Card/Card";
import UploadArea from "../../shared/ui/UploadArea/UploadArea";
import Button from "../../shared/ui/Button/Button";
import JobDescriptionAnalyzer from "../../features/job-description/JobDescriptionAnalyzer";

import { useApp } from "../../context/AppContext";

export default function EmptyScreen() {

    const {

        setState,

        resumeFilename,

        jobDescription,

    } = useApp();

    function handleAnalyze() {

        if (!resumeFilename) {

            alert("Please upload a resume.");

            return;

        }

        if (!jobDescription.trim()) {

            alert("Please paste a Job Description.");

            return;

        }

        setState("ANALYZING");

    }

    return (

        <main className={styles.page}>

            <Container>

                <Card>

                    <div className={styles.hero}>

                        <h1 className={styles.title}>
                            ResumeOptimizer
                        </h1>

                        <p className={styles.subtitle}>
                            Same Resume. Smarter Words.
                        </p>

                    </div>

                    <UploadArea />

                    <br />

                    <JobDescriptionAnalyzer />

                    <br />

                    <Button
                        onClick={handleAnalyze}
                    >
                        Analyze Resume
                    </Button>

                </Card>

            </Container>

        </main>

    );

}