from app.services.resume.loader import ResumeLoader
from app.services.resume.extractor import ResumeExtractor
from app.services.resume.profile_builder import ResumeProfileBuilder

from app.services.job_description.analyzer import JobDescriptionAnalyzer

from app.services.matching.matcher import ResumeMatcher


class ResumeAnalysisService:

    @staticmethod
    def analyze(
        resume_path: str,
        job_description: str,
    ):

        # Resume

        text = ResumeExtractor.extract(
            resume_path
        )

        resume_profile = (
            ResumeProfileBuilder.build(text)
        )

        # Job

        job_profile = (
            JobDescriptionAnalyzer.analyze(
                job_description
            )
        )

        # Match

        return ResumeMatcher.match(
            resume_profile,
            job_profile,
        )