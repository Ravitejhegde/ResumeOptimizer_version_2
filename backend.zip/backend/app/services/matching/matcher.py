from app.models.resume_profile import ResumeProfile
from app.models.job_profile import JobProfile
from app.models.match_result import MatchResult


class ResumeMatcher:

    @staticmethod
    def match(
        resume: ResumeProfile,
        job: JobProfile,
    ) -> MatchResult:

        resume_skills = {
            skill.lower()
            for skill in resume.skills
        }

        job_skills = {
            skill.lower()
            for skill in job.skills
        }

        matched = sorted(
            resume_skills & job_skills
        )

        missing = sorted(
            job_skills - resume_skills
        )

        extra = sorted(
            resume_skills - job_skills
        )

        score = 0

        if job_skills:

            score = int(
                len(matched)
                /
                len(job_skills)
                *
                100
            )

        return MatchResult(

            score=score,

            matched_skills=matched,

            missing_skills=missing,

            extra_skills=extra,

        )