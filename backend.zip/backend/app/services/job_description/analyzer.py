import re

from app.schemas.job_analysis import JobAnalysisResponse

from .keyword_extractor import KeywordExtractor


class JobDescriptionAnalyzer:

    @staticmethod
    def analyze(text: str):

        skills = KeywordExtractor.extract(text)

        title = "Unknown"

        experience = "Not Found"

        first_line = text.split("\n")[0].strip()

        if len(first_line) < 80:

            title = first_line

        match = re.search(r"(\d+\+?\s*years?)", text, re.IGNORECASE)

        if match:

            experience = match.group()

        return JobAnalysisResponse(

            title=title,

            experience=experience,

            skills=skills,

        )