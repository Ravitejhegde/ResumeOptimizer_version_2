from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    # ------------------------------------------------------------------
    # Application
    # ------------------------------------------------------------------
    APP_NAME: str = "ResumeOptimizer API"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = True

    # ------------------------------------------------------------------
    # File Upload
    # ------------------------------------------------------------------
    MAX_FILE_SIZE: int = 5 * 1024 * 1024  # 5 MB
    ALLOWED_EXTENSIONS: tuple[str, ...] = (".docx",)

    # ------------------------------------------------------------------
    # Storage
    # ------------------------------------------------------------------
    BASE_DIR: Path = Path(__file__).resolve().parents[2]

    STORAGE_DIR: Path = BASE_DIR / "storage"
    TEMP_DIR: Path = STORAGE_DIR / "temp"
    PROCESSED_DIR: Path = STORAGE_DIR / "processed"
    EXPORT_DIR: Path = STORAGE_DIR / "exports"

    model_config = SettingsConfigDict(
        env_file=".env",
        case_sensitive=True,
    )


settings = Settings()