from fastapi import APIRouter, HTTPException

from pydantic import BaseModel

from app.ai.optimizer import ResumeOptimizer

router = APIRouter(
    prefix="/optimization",
    tags=["Optimization"],
)


class OptimizeRequest(BaseModel):
    resume_filename: str
    job_description: str


@router.post("/optimize")
def optimize_resume(request: OptimizeRequest):

    resume_path = f"uploads/{request.resume_filename}"

    try:

        optimizer = ResumeOptimizer()

        result = optimizer.optimize(
            resume_path=resume_path,
            job_description=request.job_description,
        )

        return {
            "success": True,
            "sections": result,
        }

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=str(e),
        )