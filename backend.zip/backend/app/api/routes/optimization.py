from fastapi import APIRouter

from app.schemas.optimize_request import OptimizeRequest
from app.schemas.response import ApiResponse

router = APIRouter(
    prefix="/optimization",
    tags=["Optimization"],
)


@router.post("/")
async def optimize(request: OptimizeRequest):
    return ApiResponse(
        success=True,
        message="Optimization pipeline started.",
        data={
            "resume_id": request.resume_id,
            "job_description_length": len(request.job_description),
        },
    )